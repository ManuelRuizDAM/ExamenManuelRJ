package com.example.ExamenAndroidDAMTheme.data

data class LoteriaTipo (val nombre:String, val premio:Int)