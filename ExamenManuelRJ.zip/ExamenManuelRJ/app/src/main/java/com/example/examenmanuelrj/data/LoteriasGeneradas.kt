package com.example.ExamenAndroidDAMTheme.data

object DataSource {
    val loterias = arrayListOf<LoteriaTipo>(
        LoteriaTipo("Euromillon", 120),
        LoteriaTipo("Primitiva", 20),
        LoteriaTipo("LoteriaNacional", 40),
    )
}